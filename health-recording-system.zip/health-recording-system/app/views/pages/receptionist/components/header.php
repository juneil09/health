<header class="p-5 flex justify-end items-center border-b border-gray-200 bg-white">
    <div class="flex items-center gap-2">
        <i class='bx bx-bell text-gray-900' style="font-size: 1.4rem;"></i>
        <div class="avatar w-12 h-12">
            <i class="bx bx-user text-3xl"></i>
        </div>
        <div>
            <div class="text-gray-900 font-medium">Joshua</div>
            <div class="text-gray-400 text-xs">Pasyente</div>
        </div>
    </div>
</header>