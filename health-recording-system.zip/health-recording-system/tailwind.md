rm ./public/css/output.css # (Windows: del output.css) 
npx tailwindcss -i ./public/css/style.css -o ./public/css/output.css --watch
 